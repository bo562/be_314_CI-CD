from enum import Enum


class DatabaseLookups(Enum):
    User = "314-db-lambda-user"
