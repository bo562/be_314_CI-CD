from enum import Enum


class DatabaseSymbol(Enum):
    AND="AND",
    OR="OR"