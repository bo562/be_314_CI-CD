"""
py that describes the controller for the service sub-package. Enabling...
"""


class Service_Controller:
    def __init__(self):
        pass

    def create_request(self):
        pass

    def update_request(self):
        pass

    def get_request(self):
        pass

    def create_transaction(self):
        pass

    def update_transaction(self):
        pass

    def get_transaction(self):
        pass