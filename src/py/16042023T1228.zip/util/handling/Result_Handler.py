"""
py that describes the class that handles all results returned from classes and other controllers
"""


class Result_Handler:
