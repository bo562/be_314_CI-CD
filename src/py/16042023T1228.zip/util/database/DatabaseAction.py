from enum import Enum


class DatabaseAction(Enum):
    SELECT="SELECT",
    INSERT="INSERT",
    UPDATE="UPDATE",
    DELETE="DELETE"
